# =========================
# file: indoor_ODE.py
# =========================
"""
Indoor greenhouse ODE model.

State vector:
x = [T_in, H_in, C_in, L_DLI]^T
- T_in: indoor temperature [°C]
- H_in: indoor absolute humidity [g/m^3]
- C_in: indoor CO2 absolute concentration [g/m^3]
- L_DLI: daily light integral [mol/m^2]

Control input vector:
u = [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]^T
(each dimensionless, typically in [0,1])

Outdoor disturbance vector:
d = [T_out, H_out, C_out, R_out]^T
- T_out [°C], H_out [g/m^3], C_out [g/m^3], R_out [W/m^2]
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, sqrt
from typing import Tuple

import numpy as np
from numpy.typing import NDArray

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_params import GreenhouseParams, DEFAULT_PARAMS


ArrayF = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class Intermediates:
    DeltaT: float
    T_cover: float
    epsilon: float
    r_s: float
    g_tran: float
    g_vc: float
    H_in_sat: float
    H_out_sat: float
    R_in_solar: float
    R_in_LED: float
    R_in_global: float
    R_cano: float
    H_cano: float
    X_cano: float
    ventilation_flow: float  # effective ventilation + leakage [m^3/s]


def _clip01(value: float) -> float:
    return 0.0 if value < 0.0 else (1.0 if value > 1.0 else value)


def _effective_ventilation_flow(u_fan: float, u_nat: float, p: GreenhouseParams) -> float:
    # (V_fan*U_fan + V_nat*U_nat + lambda_leak*V_gh/3600)
    return (p.bar_V_fan * u_fan) + (p.bar_V_nat * u_nat) + (p.lambda_leak * p.V_gh / 3600.0)


def compute_intermediates(
    x: ArrayF,
    u: ArrayF,
    d: ArrayF,
    p: GreenhouseParams = DEFAULT_PARAMS,
) -> Intermediates:
    T_in, H_in, C_in, _L_DLI = map(float, x.tolist())
    U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum = map(float, u.tolist())
    T_out, H_out, C_out, R_out = map(float, d.tolist())

    U_fan = _clip01(U_fan)
    U_nat = _clip01(U_nat)
    U_pad = _clip01(U_pad)
    U_LED = _clip01(U_LED)

    DeltaT = T_in - T_out
    T_cover = (2.0 * T_out + T_in) / 3.0

    # epsilon = 0.7584 * exp(delta_tran * T_in)
    epsilon = 0.7584 * exp(p.delta_tran * T_in)

    # Radiation terms
    R_in_solar = (
        p.eta_cover * (p.A_roof + p.eta_wall * p.A_wall) * R_out / p.A_floor
    )
    R_in_LED = (
        p.eta_LED_cano * p.eta_LED_r * p.bar_P_LED * U_LED / p.A_floor
    )
    R_in_global = R_in_solar + R_in_LED

    # R_cano = eta_short * [(exp(eta_ext*L)-1)/exp(eta_ext*L)] * R_in_global
    exp_extL = exp(p.eta_ext * p.L)
    R_cano = p.eta_short * ((exp_extL - 1.0) / exp_extL) * R_in_global

    # r_s = [r_s_min + r_s_max * exp(-tau*R_cano/L)] * [1 + delta_sr*(T_in - T_sr)^2]
    r_s = (p.underline_r_s + p.bar_r_s * exp(-(p.tau * R_cano) / p.L)) * (
        1.0 + p.delta_sr * (T_in - p.T_sr) ** 2
    )

    # g_tran = 2*L / ((1+epsilon)*r_b + r_s)
    denom = ((1.0 + epsilon) * p.r_b) + r_s
    g_tran = (2.0 * p.L) / denom if denom > 0.0 else 0.0

    # Saturation humidities
    H_in_sat = p.tilde_H * exp(p.delta_sat * T_in)
    H_out_sat = p.tilde_H * exp(p.delta_sat * T_out)

    # H_cano = H_in_sat + epsilon * r_b * R_cano / (2*L*q_evap)
    H_cano = H_in_sat + (epsilon * p.r_b * R_cano) / (2.0 * p.L * p.q_evap)

    # g_vc = nu_surf * ( ((T_in-T_cover)+sqrt((T_in-T_cover)^2 + sigma^2))/2 )^(1/3)
    temp = ((T_in - T_cover) + sqrt((T_in - T_cover) ** 2 + p.sigma**2)) / 2.0
    g_vc = p.nu_surf * (temp ** (1.0 / 3.0)) if temp > 0.0 else 0.0

    # PPFD
    X_cano = p.phi_solar * R_in_solar + p.phi_LED * R_in_LED

    ventilation_flow = _effective_ventilation_flow(U_fan, U_nat, p)

    return Intermediates(
        DeltaT=DeltaT,
        T_cover=T_cover,
        epsilon=epsilon,
        r_s=r_s,
        g_tran=g_tran,
        g_vc=g_vc,
        H_in_sat=H_in_sat,
        H_out_sat=H_out_sat,
        R_in_solar=R_in_solar,
        R_in_LED=R_in_LED,
        R_in_global=R_in_global,
        R_cano=R_cano,
        H_cano=H_cano,
        X_cano=X_cano,
        ventilation_flow=ventilation_flow,
    )


def greenhouse_ode(
    t: float,
    x: ArrayF,
    u: ArrayF,
    d: ArrayF,
    p: GreenhouseParams = DEFAULT_PARAMS,
) -> ArrayF:
    """
    Continuous-time dynamics: x_dot = f(x,u,d).
    """
    T_in, H_in, C_in, _L_DLI = map(float, x.tolist())
    U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum = map(float, u.tolist())
    T_out, H_out, C_out, R_out = map(float, d.tolist())

    # Keep actuator inputs sane (utils for MPC/RL setups)
    U_heat = _clip01(U_heat)
    U_fan = _clip01(U_fan)
    U_nat = _clip01(U_nat)
    U_pad = _clip01(U_pad)
    U_dos = _clip01(U_dos)
    U_LED = _clip01(U_LED)
    U_hum = _clip01(U_hum)
    U_dehum = _clip01(U_dehum)

    inter = compute_intermediates(
        x=np.array([T_in, H_in, C_in, _L_DLI], dtype=np.float64),
        u=np.array([U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum], dtype=np.float64),
        d=np.array([T_out, H_out, C_out, R_out], dtype=np.float64),
        p=p,
    )

    # --- Temperature dynamics ---
    Q_heat = p.bar_Q_heat * U_heat

    Q_vent = p.c_vh * inter.DeltaT * inter.ventilation_flow

    Q_cool = (
        p.c_vh * p.DeltaT_pad * p.bar_V_fan * U_fan * U_pad
        + p.q_evap * p.eta_evap * p.bar_F_hum * U_hum
    )

    Q_solar = inter.R_in_solar * p.A_floor

    Q_DeltaT = (p.upsilon_roof * p.A_roof + p.upsilon_wall * p.A_wall) * inter.DeltaT

    Q_LED = p.eta_LED_h * p.bar_P_LED * U_LED

    Q_tran = p.q_evap * inter.g_tran * (inter.H_cano - H_in) * p.A_floor

    dT_in_dt = (Q_heat - Q_vent - Q_cool + Q_solar - Q_DeltaT + Q_LED - Q_tran) / (p.eta_thermal * p.V_gh * p.c_vh)

    # --- Humidity dynamics ---
    F_cool = (
        (p.c_vh * p.DeltaT_pad * p.bar_V_fan * U_fan * U_pad) / p.q_evap
        + p.eta_evap * p.bar_F_hum * U_hum
    )
    F_dehum = p.bar_F_dehum * U_dehum
    F_vent = (H_in - H_out) * inter.ventilation_flow
    F_tran = inter.g_tran * (inter.H_cano - H_in) * p.A_floor
    F_vc = inter.g_vc * (
        (p.zeta * exp(p.delta_vc * T_in) * inter.DeltaT) - (inter.H_in_sat - H_in)
    ) * p.A_floor

    dH_in_dt = (F_cool - F_dehum - F_vent + F_tran - F_vc) / (p.eta_hum * p.V_gh)

    # --- CO2 dynamics ---
    D_dos = p.bar_D_dos * U_dos
    D_vent = (C_in - C_out) * inter.ventilation_flow

    C_in_safe = max(C_in, 1e-9)
    D_ass = (
        p.bar_D_ass
        * (1.0 / (1.0 + (p.hat_C_in / C_in_safe)))
        * (1.0 - exp(-p.rho * inter.X_cano))
        * p.A_floor
    )

    dC_in_dt = (D_dos - D_vent - D_ass) / p.V_gh

    # --- DLI dynamics ---
    dL_DLI_dt = inter.X_cano / 1e6

    return np.array([dT_in_dt, dH_in_dt, dC_in_dt, dL_DLI_dt], dtype=np.float64)


def unpack_state(x: ArrayF) -> Tuple[float, float, float, float]:
    """Convenience: returns (T_in, H_in, C_in, L_DLI)."""
    return float(x[0]), float(x[1]), float(x[2]), float(x[3])

