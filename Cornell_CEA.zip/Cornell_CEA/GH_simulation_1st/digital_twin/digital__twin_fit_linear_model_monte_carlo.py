# =========================
# file: digital__twin_fit_linear_model_monte_carlo.py
# =========================
"""
Monte-Carlo linearization via one-step simulation + multivariate linear regression.

Fits:
    x_{k+1} = M x_k + N u_k + O d_k + m

Where:
- x in R^4  : [T_in, H_in, C_in, L_DLI]
- u in R^8  : [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]
- d in R^4  : [T_out, H_out, C_out, R_out]

Saves:
- matrices .npz: M, N, O, m
- (optional) dataset .npz: X, U, D, Y
"""

from __future__ import annotations

import argparse
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple

import numpy as np
from numpy.typing import NDArray

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_one_step_RK4 import simulate_one_step  # uses greenhouse_ode internally
from GH_simulation_1st.digital_twin_for_real_response.digital_twin_params import DEFAULT_PARAMS

ArrayF = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class SampleRanges:
    """
    Default sampling ranges (edit for your greenhouse).

    Notes:
    - Keep ranges realistic; overly wide ranges can yield poor linear fits.
    - CO2 is in g/m^3 in this model.
    """
    # state x = [T_in, H_in, C_in, L_DLI]
    T_in: Tuple[float, float] = (5.0, 35.0)       # °C
    H_in: Tuple[float, float] = (0.0, 30.0)       # g/m^3
    C_in: Tuple[float, float] = (0.02, 2.0)       # g/m^3 (avoid near-zero)
    L_DLI: Tuple[float, float] = (0.0, 60.0)      # mol/m^2

    # control u in [0,1]
    u_min: float = 0.0
    u_max: float = 1.0

    # disturbance d = [T_out, H_out, C_out, R_out]
    T_out: Tuple[float, float] = (-10.0, 40.0)    # °C
    H_out: Tuple[float, float] = (0.0, 30.0)      # g/m^3
    C_out: Tuple[float, float] = (0.02, 2.0)      # g/m^3
    R_out: Tuple[float, float] = (0.0, 1000.0)    # W/m^2


def _uniform(rng: np.random.Generator, lo: float, hi: float, size: int) -> ArrayF:
    return rng.uniform(lo, hi, size=size).astype(np.float64)


def sample_one(rng: np.random.Generator, r: SampleRanges) -> Tuple[ArrayF, ArrayF, ArrayF]:
    x = np.array(
        [
            _uniform(rng, *r.T_in, 1)[0],
            _uniform(rng, *r.H_in, 1)[0],
            _uniform(rng, *r.C_in, 1)[0],
            _uniform(rng, *r.L_DLI, 1)[0],
        ],
        dtype=np.float64,
    )
    u = _uniform(rng, r.u_min, r.u_max, 8)
    d = np.array(
        [
            _uniform(rng, *r.T_out, 1)[0],
            _uniform(rng, *r.H_out, 1)[0],
            _uniform(rng, *r.C_out, 1)[0],
            _uniform(rng, *r.R_out, 1)[0],
        ],
        dtype=np.float64,
    )
    return x, u, d


def simulate_one_step_safe(
    x: ArrayF,
    u: ArrayF,
    d: ArrayF,
    horizon_s: float,
    dt_s: float,
    y_abs_clip: float,
    y_bounds: Tuple[Tuple[float, float], ...],
) -> Tuple[bool, ArrayF]:
    """
    Returns (ok, y). ok=False if y is non-finite or outside bounds.

    Bounds are per state: (T_in, H_in, C_in, L_DLI).
    """
    try:
        res = simulate_one_step(
            x_ini=x,
            u=u,
            d=d,
            p=DEFAULT_PARAMS,
            horizon_s=horizon_s,
            dt_s=dt_s,
            t0=0.0,
        )
        y = np.asarray(res.x1, dtype=np.float64)

        if y.shape != (4,):
            return False, y
        if not np.all(np.isfinite(y)):
            return False, y

        if float(np.max(np.abs(y))) > y_abs_clip:
            return False, y

        for i, (lo, hi) in enumerate(y_bounds):
            if not (lo <= float(y[i]) <= hi):
                return False, y

        return True, y
    except Exception:
        return False, np.full((4,), np.nan, dtype=np.float64)


def _print_progress(good: int, n_samples: int, tries: int, dropped: int, start_t: float) -> None:
    elapsed = time.perf_counter() - start_t
    accept_rate = (good / tries) if tries > 0 else 0.0
    pct = (100.0 * good / n_samples) if n_samples > 0 else 0.0
    print(
        f"[MC] accepted={good}/{n_samples} ({pct:6.2f}%) | tries={tries} | "
        f"accept_rate={accept_rate:6.2%} | dropped={dropped} | elapsed={elapsed:8.1f}s",
        flush=True,
    )


def build_dataset(
    n_samples: int,
    seed: int,
    horizon_s: float,
    dt_s: float,
    ranges: SampleRanges,
    max_tries_factor: int = 10,
    log_every: int = 500,
    log_time_s: float = 10.0,
    y_abs_clip: float = 1e6,
    y_bounds: Tuple[Tuple[float, float], ...] = ((-30.0, 60.0), (0.0, 40.0), (0.0, 5.0), (0.0, 200.0)),
) -> Tuple[ArrayF, ArrayF, ArrayF, ArrayF]:
    rng = np.random.default_rng(seed)

    X = np.zeros((n_samples, 4), dtype=np.float64)
    U = np.zeros((n_samples, 8), dtype=np.float64)
    D = np.zeros((n_samples, 4), dtype=np.float64)
    Y = np.zeros((n_samples, 4), dtype=np.float64)

    good = 0
    tries = 0
    dropped = 0
    max_tries = max_tries_factor * n_samples

    start_t = time.perf_counter()
    last_log_t = start_t
    next_log_good = min(log_every, n_samples) if log_every > 0 else n_samples

    _print_progress(good=good, n_samples=n_samples, tries=tries, dropped=dropped, start_t=start_t)

    while good < n_samples and tries < max_tries:
        tries += 1
        x, u, d = sample_one(rng, ranges)
        ok, y = simulate_one_step_safe(
            x, u, d,
            horizon_s=horizon_s,
            dt_s=dt_s,
            y_abs_clip=y_abs_clip,
            y_bounds=y_bounds,
        )
        if not ok:
            dropped += 1
            now = time.perf_counter()
            if log_time_s > 0 and (now - last_log_t) >= log_time_s:
                _print_progress(good=good, n_samples=n_samples, tries=tries, dropped=dropped, start_t=start_t)
                last_log_t = now
            continue

        X[good] = x
        U[good] = u
        D[good] = d
        Y[good] = y
        good += 1

        now = time.perf_counter()
        if (log_every > 0 and good >= next_log_good) or (log_time_s > 0 and (now - last_log_t) >= log_time_s):
            _print_progress(good=good, n_samples=n_samples, tries=tries, dropped=dropped, start_t=start_t)
            last_log_t = now
            if log_every > 0:
                next_log_good = min(next_log_good + log_every, n_samples)

    if good < n_samples:
        raise RuntimeError(
            f"Could not collect enough valid samples. Requested {n_samples}, got {good} "
            f"after {tries} tries. dropped={dropped}. "
            f"Try tightening ranges / reducing horizon_s / relaxing bounds."
        )

    _print_progress(good=good, n_samples=n_samples, tries=tries, dropped=dropped, start_t=start_t)
    return X, U, D, Y


def fit_affine_model(
    X: ArrayF,
    U: ArrayF,
    D: ArrayF,
    Y: ArrayF,
    ridge_lambda: float,
    standardize: bool = True,
    regularize_bias: bool = False,
    verbose: bool = True,
) -> Tuple[ArrayF, ArrayF, ArrayF, ArrayF]:
    """
    Stable multivariate ridge regression without forming Phi^T Phi.

    Solves:
        min_Theta ||Phi Theta - Y||^2 + ridge_lambda * ||W Theta||^2

    Where:
      Phi = [X U D 1]
      W is identity (except optional bias column).

    Returns M,N,O,m in:
        x_{k+1} = M x_k + N u_k + O d_k + m
    """
    n = X.shape[0]
    Phi = np.hstack([X, U, D, np.ones((n, 1), dtype=np.float64)])  # (n,17)
    Y = np.asarray(Y, dtype=np.float64)

    mask = np.isfinite(Phi).all(axis=1) & np.isfinite(Y).all(axis=1)
    if verbose and int(mask.sum()) != n:
        print(f"[REG] Dropping {n - int(mask.sum())} non-finite rows before regression.")
    Phi = Phi[mask]
    Y = Y[mask]

    if Phi.shape[0] < 10:
        raise RuntimeError(f"Too few valid samples after filtering: {Phi.shape[0]}")

    if standardize:
        Z = Phi[:, :16]
        b = Phi[:, 16:17]

        mu = Z.mean(axis=0)
        sigma = Z.std(axis=0)
        sigma = np.where(sigma < 1e-12, 1.0, sigma)

        Zs = (Z - mu) / sigma
        Phi_s = np.hstack([Zs, b])  # (n,17)
    else:
        mu = np.zeros((16,), dtype=np.float64)
        sigma = np.ones((16,), dtype=np.float64)
        Phi_s = Phi

    p = Phi_s.shape[1]  # 17
    if ridge_lambda > 0.0:
        L = np.sqrt(ridge_lambda) * np.eye(p, dtype=np.float64)
        if not regularize_bias:
            L[-1, -1] = 0.0
        Phi_aug = np.vstack([Phi_s, L])
        Y_aug = np.vstack([Y, np.zeros((p, Y.shape[1]), dtype=np.float64)])
    else:
        Phi_aug = Phi_s
        Y_aug = Y

    Theta_s, *_ = np.linalg.lstsq(Phi_aug, Y_aug, rcond=None)  # (17,4)

    if standardize:
        Theta_Zs = Theta_s[:16, :]
        Theta_b = Theta_s[16, :]

        Theta_Z = Theta_Zs / sigma[:, None]
        mu_over_sigma = mu / sigma
        Theta_bias = Theta_b - (mu_over_sigma @ Theta_Zs)
        Theta = np.vstack([Theta_Z, Theta_bias.reshape(1, -1)])  # (17,4)
    else:
        Theta = Theta_s

    Theta_x = Theta[0:4, :]
    Theta_u = Theta[4:12, :]
    Theta_d = Theta[12:16, :]
    Theta_b = Theta[16:17, :]

    M = Theta_x.T.copy()                 # (4,4)
    N = Theta_u.T.copy()                 # (4,8)
    O = Theta_d.T.copy()                 # (4,4)
    m = Theta_b.reshape(-1).copy()       # (4,)

    if verbose:
        max_abs = float(np.max(np.abs(Phi[:, :16]))) if Phi.size else 0.0
        print(f"[REG] standardize={standardize}, ridge_lambda={ridge_lambda}, max|features|≈{max_abs:.3g}")

    return M, N, O, m


def eval_fit(
    M: ArrayF,
    N: ArrayF,
    O: ArrayF,
    m: ArrayF,
    X: ArrayF,
    U: ArrayF,
    D: ArrayF,
    Y: ArrayF,
    clip_pred_abs: float = 1e12,
    verbose: bool = True,
) -> None:
    """
    Robust evaluation:
    - filters any non-finite rows
    - computes prediction in longdouble to reduce overflow risk
    - clips extreme predictions for metrics printing
    """

    def _stat(name: str, a: np.ndarray) -> None:
        finite = bool(np.isfinite(a).all())
        mx = float(np.nanmax(np.abs(a))) if a.size else 0.0
        print(f"[EVAL] {name}: finite={finite} max|.|={mx:.3g}")

    if verbose:
        _stat("X", X)
        _stat("U", U)
        _stat("D", D)
        _stat("Y", Y)
        _stat("M", M)
        _stat("N", N)
        _stat("O", O)
        _stat("m", m)

    if not (np.isfinite(M).all() and np.isfinite(N).all() and np.isfinite(O).all() and np.isfinite(m).all()):
        raise RuntimeError("Non-finite coefficients in M/N/O/m. Increase --ridge-lambda and/or tighten sampling.")

    mask = (
        np.isfinite(X).all(axis=1)
        & np.isfinite(U).all(axis=1)
        & np.isfinite(D).all(axis=1)
        & np.isfinite(Y).all(axis=1)
    )
    Xf, Uf, Df, Yf = X[mask], U[mask], D[mask], Y[mask]
    if Xf.shape[0] == 0:
        raise RuntimeError("No valid rows for evaluation after filtering.")

    ld = np.longdouble
    Xld = Xf.astype(ld, copy=False)
    Uld = Uf.astype(ld, copy=False)
    Dld = Df.astype(ld, copy=False)
    Mld = M.astype(ld, copy=False)
    Nld = N.astype(ld, copy=False)
    Old = O.astype(ld, copy=False)
    mld = m.astype(ld, copy=False)

    Yhat_ld = (Xld @ Mld.T) + (Uld @ Nld.T) + (Dld @ Old.T) + mld
    Yhat = np.asarray(Yhat_ld, dtype=np.float64)

    if not np.isfinite(Yhat).all():
        bad = int((~np.isfinite(Yhat)).any(axis=1).sum())
        print(
            f"[EVAL] Warning: non-finite predictions in {bad}/{Yhat.shape[0]} rows. "
            f"Try larger --ridge-lambda or tighter dataset bounds."
        )

    Yhat = np.clip(Yhat, -clip_pred_abs, clip_pred_abs)

    err = Yhat - Yf
    rmse = np.sqrt(np.mean(err**2, axis=0))
    var = np.var(Yf, axis=0)
    r2 = 1.0 - (np.var(err, axis=0) / (var + 1e-12))

    print("Fit quality (per state dimension [T_in, H_in, C_in, L_DLI]):")
    print("  RMSE:", rmse)
    print("  R^2 :", r2)


def print_matrices(
    M: ArrayF,
    N: ArrayF,
    O: ArrayF,
    m: ArrayF,
    precision: int = 6,
) -> None:
    np.set_printoptions(
        precision=precision,
        suppress=True,
        linewidth=200,
        floatmode="maxprec_equal",
    )

    print("\n====================")
    print("Learned linear model:")
    print("x_{k+1} = M x_k + N u_k + O d_k + m")
    print("====================")

    print("\nM (4x4)  rows=[T_in,H_in,C_in,L_DLI] cols=[T_in,H_in,C_in,L_DLI]:\n", M)
    print("\nN (4x8)  rows=[T_in,H_in,C_in,L_DLI] cols=[U_heat,U_fan,U_nat,U_pad,U_dos,U_LED,U_hum,U_dehum]:\n", N)
    print("\nO (4x4)  rows=[T_in,H_in,C_in,L_DLI] cols=[T_out,H_out,C_out,R_out]:\n", O)
    print("\nm (4,)   [T_in,H_in,C_in,L_DLI]:\n", m)
    print("====================\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-samples", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--horizon-s", type=float, default=300.0)
    ap.add_argument("--dt-s", type=float, default=5.0)

    ap.add_argument("--ridge-lambda", type=float, default=1e-4)
    ap.add_argument("--standardize", action="store_true", default=True)
    ap.add_argument("--no-standardize", dest="standardize", action="store_false")
    ap.add_argument("--regularize-bias", action="store_true", default=False)

    ap.add_argument("--out-model", type=str, default="linear_model_matrices.npz")
    ap.add_argument("--out-dataset", type=str, default="")

    ap.add_argument("--log-every", type=int, default=500)
    ap.add_argument("--log-time-s", type=float, default=10.0)

    ap.add_argument("--y-abs-clip", type=float, default=1e6)
    ap.add_argument("--yT-min", type=float, default=-30.0)
    ap.add_argument("--yT-max", type=float, default=60.0)
    ap.add_argument("--yH-min", type=float, default=0.0)
    ap.add_argument("--yH-max", type=float, default=40.0)
    ap.add_argument("--yC-min", type=float, default=0.0)
    ap.add_argument("--yC-max", type=float, default=5.0)
    ap.add_argument("--yL-min", type=float, default=0.0)
    ap.add_argument("--yL-max", type=float, default=200.0)

    ap.add_argument("--clip-pred-abs", type=float, default=1e12)

    # NEW: printing controls
    ap.add_argument("--print-matrices", action="store_true", default=True)
    ap.add_argument("--no-print-matrices", dest="print_matrices", action="store_false")
    ap.add_argument("--print-precision", type=int, default=6)

    args = ap.parse_args()

    ranges = SampleRanges()
    y_bounds = (
        (args.yT_min, args.yT_max),
        (args.yH_min, args.yH_max),
        (args.yC_min, args.yC_max),
        (args.yL_min, args.yL_max),
    )

    print(
        f"Generating dataset: n={args.n_samples}, seed={args.seed}, "
        f"horizon_s={args.horizon_s}, dt_s={args.dt_s}"
    )
    X, U, D, Y = build_dataset(
        n_samples=args.n_samples,
        seed=args.seed,
        horizon_s=args.horizon_s,
        dt_s=args.dt_s,
        ranges=ranges,
        log_every=args.log_every,
        log_time_s=args.log_time_s,
        y_abs_clip=args.y_abs_clip,
        y_bounds=y_bounds,
    )

    print("Fitting affine model...")
    M, N, O, m = fit_affine_model(
        X, U, D, Y,
        ridge_lambda=args.ridge_lambda,
        standardize=args.standardize,
        regularize_bias=args.regularize_bias,
        verbose=True,
    )
    eval_fit(M, N, O, m, X, U, D, Y, clip_pred_abs=args.clip_pred_abs, verbose=True)

    if args.print_matrices:
        print_matrices(M, N, O, m, precision=args.print_precision)

    out_model = Path(args.out_model)
    out_model.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        out_model,
        M=M, N=N, O=O, m=m,
        horizon_s=np.float64(args.horizon_s),
        dt_s=np.float64(args.dt_s),
        seed=np.int64(args.seed),
        n_samples=np.int64(args.n_samples),
        ridge_lambda=np.float64(args.ridge_lambda),
        standardize=np.bool_(args.standardize),
        regularize_bias=np.bool_(args.regularize_bias),
        y_abs_clip=np.float64(args.y_abs_clip),
        y_bounds=np.asarray(y_bounds, dtype=np.float64),
    )
    print(f"Saved model matrices to: {out_model.resolve()}")

    if args.out_dataset:
        out_ds = Path(args.out_dataset)
        out_ds.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(out_ds, X=X, U=U, D=D, Y=Y)
        print(f"Saved dataset to: {out_ds.resolve()}")

    print("Done.")


if __name__ == "__main__":
    main()
