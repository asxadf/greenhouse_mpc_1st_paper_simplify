# =========================
# file: gh_mpc_constants_v2.py
# =========================
"""
MPC constants + time-dependent bounds/references + plotting helpers.

State x = [T_in, H_in, C_in, L_DLI]
Control u = [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]
Disturbance d = [T_out, H_out, C_out, R_out]
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, time as dtime
from typing import Tuple

import numpy as np
from numpy.typing import NDArray

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_params import DEFAULT_PARAMS

ArrayF = NDArray[np.float64]


@dataclass(frozen=True, slots=True)
class MPCParams:
    """
    Parameters from your LaTeX table + slack penalties for soft constraints.
    """
    K: int = 12
    dt_s: float = 300.0
    gamma: float = 0.99

    # prices
    alpha_heat: float = 0.016
    alpha_elec: float = 0.134
    alpha_hum: float = 3.53e-6
    alpha_dehum: float = 7.9e-5
    alpha_dos: float = 7.4e-4

    # fan
    S_fan: float = 93.4  # W/(m^3/s)

    # tracking
    lambda_T: float = 0.20
    lambda_H: float = 0.05
    lambda_C: float = 0.03
    lambda_L: float = 0.10

    # soft-constraint penalties (quadratic) for bound violations
    slack_T: float = 1e4
    slack_H: float = 1e4
    slack_C: float = 1e4


@dataclass(frozen=True, slots=True)
class StateBounds:
    """
    Light window: 06:00–22:00.

    Bounds for [T_in, H_in, C_in] depend on light/dark.
    L_DLI is unconstrained in MPC by setting wide bounds.
    """
    # Temperature [°C]
    T_light_min: float = 21.0
    T_light_max: float = 26.0
    T_dark_min: float = 16.0
    T_dark_max: float = 19.0

    # Humidity [g/m^3]
    H_light_min: float = 12.5
    H_light_max: float = 17.5
    H_dark_min: float = 10.0
    H_dark_max: float = 13.2

    # CO2 [g/m^3]
    C_light_min: float = 0.7283
    C_light_max: float = 1.8208
    C_dark_min: float = 0.7283
    C_dark_max: float = 1.0925

    # L_DLI wide bounds
    L_min: float = -1e9
    L_max: float = +1e9


def is_light_period(dt: datetime) -> bool:
    t = dt.time()
    return dtime(6, 0) <= t < dtime(22, 0)


def x_bounds_for_time(dt: datetime, b: StateBounds) -> Tuple[ArrayF, ArrayF]:
    if is_light_period(dt):
        T_lo, T_hi = b.T_light_min, b.T_light_max
        H_lo, H_hi = b.H_light_min, b.H_light_max
        C_lo, C_hi = b.C_light_min, b.C_light_max
    else:
        T_lo, T_hi = b.T_dark_min, b.T_dark_max
        H_lo, H_hi = b.H_dark_min, b.H_dark_max
        C_lo, C_hi = b.C_dark_min, b.C_dark_max

    x_lo = np.array([T_lo, H_lo, C_lo, b.L_min], dtype=np.float64)
    x_hi = np.array([T_hi, H_hi, C_hi, b.L_max], dtype=np.float64)
    return x_lo, x_hi


def l_dli_star_for_time(dt: datetime) -> float:
    """
    L^{DLI*} reference:
      - 00:00–06:00: 0
      - 06:00–22:00: linear 0 -> 26
      - 22:00–24:00: 26
    """
    minutes = dt.hour * 60 + dt.minute
    if minutes < 6 * 60:
        return 0.0
    if minutes < 22 * 60:
        frac = (minutes - 6 * 60) / float((22 - 6) * 60)
        return 26.0 * frac
    return 26.0


def x_star_for_time(dt: datetime, b: StateBounds) -> ArrayF:
    lo, hi = x_bounds_for_time(dt, b)
    return np.array(
        [
            0.5 * (lo[0] + hi[0]),
            0.5 * (lo[1] + hi[1]),
            0.5 * (lo[2] + hi[2]),
            l_dli_star_for_time(dt),
        ],
        dtype=np.float64,
    )


def stage_energy_coeffs(params: MPCParams) -> ArrayF:
    """
    stage_energy_cost = c_u @ u
    u = [heat, fan, nat, pad, dos, LED, hum, dehum]
    """
    p = DEFAULT_PARAMS
    dt_to_kwh = params.dt_s / 3.6e6

    c = np.zeros((8,), dtype=np.float64)
    c[0] = params.alpha_heat * p.bar_Q_heat * dt_to_kwh
    c[1] = params.alpha_elec * params.S_fan * p.bar_V_fan * dt_to_kwh
    c[5] = params.alpha_elec * p.bar_P_LED * dt_to_kwh
    c[6] = params.alpha_hum * p.bar_F_hum * params.dt_s
    c[7] = params.alpha_dehum * p.bar_F_dehum * params.dt_s
    c[4] = params.alpha_dos * p.bar_D_dos * params.dt_s
    return c


def light_dark_spans(index) -> list[tuple]:
    """
    Returns list of (start_ts, end_ts, is_light) spans over the given time index.
    Light: 06:00–22:00.
    """
    import pandas as pd

    t = pd.to_datetime(index)
    if len(t) == 0:
        return []

    spans: list[tuple] = []
    cur_start = t[0]
    cur_is_light = is_light_period(cur_start.to_pydatetime())

    for i in range(1, len(t)):
        is_l = is_light_period(t[i].to_pydatetime())
        if is_l != cur_is_light:
            spans.append((cur_start, t[i], cur_is_light))
            cur_start = t[i]
            cur_is_light = is_l

    spans.append((cur_start, t[-1], cur_is_light))
    return spans
