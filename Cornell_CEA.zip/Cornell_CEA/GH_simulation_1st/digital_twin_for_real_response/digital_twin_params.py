# =========================
# file: digital_twin_params.py
# =========================
"""
Greenhouse model parameters (state-space model).

Naming convention:
- Mirrors LaTeX as closely as valid Python identifiers allow.
- Superscripts like "^{in}" become suffixes like "_in".
- Bars/underlines/hats use prefixes: bar_, underline_, hat_.
- Greek letters use their English names: beta_, eta_, phi_, zeta_, sigma_, nu_, rho_, tau_, delta_, lambda_.

Edit values here to revise the model without touching dynamics code.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class GreenhouseParams:
    # --- Areas ---
    A_floor: float  # Floor area. [m^2]
    A_roof: float   # Roof area. [m^2]
    A_wall: float   # Side-wall area. [m^2]

    # --- CO2 conversion / constants ---
    beta_C: float        # CO2 unit conversion factor. [ppm·m^3/g]
    c_vh: float          # Air volumetric heat capacity. [J/(m^3·°C)]
    hat_C_in: float      # CO2 half-saturation constant. [g/m^3]

    # --- Actuator maxima ---
    bar_D_dos: float     # Maximum CO2 dosing rate. [g/s]
    bar_D_ass: float     # Maximum CO2 assimilation flux. [g/(m^2·s)]
    bar_F_hum: float     # Maximum injection rate of mist water. [g/s]
    bar_F_dehum: float   # Maximum moisture removal rate. [g/s]
    bar_P_LED: float     # Maximum electrical power of LEDs. [W]
    bar_Q_heat: float    # Maximum power from heaters. [W]
    bar_V_fan: float     # Maximum mechanical ventilation rate. [m^3/s]
    bar_V_nat: float     # Maximum natural ventilation rate. [m^3/s]

    # --- Humidity / evap / thermals ---
    tilde_H: float       # Empirical coefficient. [g/m^3]
    L: float             # Leaf area index. [m^2/m^2]
    rho: float           # PPFD response coefficient. [(m^2·s)/µmol]
    q_evap: float        # Latent heat of evaporation. [J/g]

    upsilon_roof: float  # Heat-transfer coefficient of roofs. [W/(m^2·°C)]
    upsilon_wall: float  # Heat-transfer coefficient of side walls. [W/(m^2·°C)]
    nu_surf: float       # Condensation surface coefficient. [m/(°C^(1/3)·s)]

    V_gh: float          # Indoor volume. [m^3]

    # --- Resistances ---
    r_b: float               # Boundary layer resistance. [s/m]
    bar_r_s: float           # Maximum additional resistance. [s/m]
    underline_r_s: float     # Minimal stomatal resistance. [s/m]

    # --- Crop / cooling / reference ---
    tau: float               # Crop-specific coefficient. [m^2/W]
    DeltaT_pad: float        # Air temperature drop due to cooling pads. [°C]
    T_sr: float              # Reference temperature. [°C]

    # --- Radiation to PPFD ---
    phi_solar: float         # Solar radiation-to-PPFD coefficient. [µmol/(W·s)]
    phi_LED: float           # LED radiation-to-PPFD coefficient. [µmol/(W·s)]

    # --- Leakage ---
    lambda_leak: float       # Air leakage rate. [h^-1]

    # --- Condensation / smoothing / sensitivities ---
    zeta: float              # Empirical coefficient. [g/(m^3·°C)]
    sigma: float             # Smoothing coefficient. [°C]

    delta_tran: float        # Temperature sensitivity coefficient. [°C^-1]
    delta_sat: float         # Temperature sensitivity coefficient. [°C^-1]
    delta_vc: float          # Temperature sensitivity coefficient. [°C^-1]
    delta_sr: float          # Temperature sensitivity coefficient. [°C^-2]

    # --- Fractions / optical parameters ---
    eta_LED_h: float         # LED power to sensible heat fraction. [-]
    eta_LED_r: float         # LED power to radiation fraction. [-]
    eta_LED_cano: float      # LED radiation to canopy fraction. [-]
    eta_evap: float          # Water evaporation fraction. [-]
    eta_cover: float         # Cover shortwave transmissivity. [-]
    eta_wall: float          # Side-wall shortwave contribution factor. [-]
    eta_short: float         # Shortwave absorption ratio. [-]
    eta_ext: float           # Light extinction coefficient. [-]
    eta_thermal: float       # Thermal inertia coefficient. [-]
    eta_hum: float           # Humidity buffering coefficient. [-]

DEFAULT_PARAMS = GreenhouseParams(
    # Areas
    A_floor=421.0,   # [m^2]
    A_roof=472.0,    # [m^2]
    A_wall=628.0,    # [m^2]

    # CO2 conversion / constants
    beta_C=549.2,    # [ppm·m^3/g]
    c_vh=1230.0,     # [J/(m^3·°C)]
    hat_C_in=0.23,   # [g/m^3]

    # Actuator maxima
    bar_D_dos=3.0,        # [g/s]
    bar_D_ass=0.0022,     # [g/(m^2·s)]
    bar_F_hum=25.0,       # [g/s]
    bar_F_dehum=20.0,     # [g/s]
    bar_P_LED=42000.0,    # [W]
    bar_Q_heat=236181.0,  # [W]
    bar_V_fan=48.0,       # [m^3/s]
    bar_V_nat=5.0,        # [m^3/s]

    # Humidity / evap / thermals
    tilde_H=5.5638,   # [g/m^3]
    L=4.5,            # [m^2/m^2]
    rho=0.0015,       # [(m^2·s)/µmol]
    q_evap=2430.0,    # [J/g]

    upsilon_roof=6.6,    # [W/(m^2·°C)]
    upsilon_wall=6.3,    # [W/(m^2·°C)]
    nu_surf=0.0018,      # [m/(°C^(1/3)·s)]

    V_gh=3351.0,       # [m^3]

    # Resistances
    r_b=200.0,           # [s/m]
    bar_r_s=570.0,       # [s/m]
    underline_r_s=82.0,  # [s/m]

    # Crop / cooling / reference
    tau=0.4,           # [m^2/W]
    DeltaT_pad=5.0,    # [°C]
    T_sr=24.5,         # [°C]

    # Radiation to PPFD
    phi_solar=2.0,     # [µmol/(W·s)]
    phi_LED=5.14,      # [µmol/(W·s)]

    # Leakage
    lambda_leak=1.0,   # [h^-1]

    # Condensation / smoothing / sensitivities
    zeta=0.2522,       # [g/(m^3·°C)]
    sigma=0.001,       # [°C]

    delta_tran=0.0518,  # [°C^-1]
    delta_sat=0.0572,   # [°C^-1]
    delta_vc=0.0485,    # [°C^-1]
    delta_sr=0.023,     # [°C^-2]

    # Fractions / optical parameters
    eta_LED_h=0.45,      # [-]
    eta_LED_r=0.55,      # [-]
    eta_LED_cano=0.40,   # [-]
    eta_evap=0.70,       # [-]
    eta_cover=0.50,      # [-]
    eta_wall=0.50,       # [-]
    eta_short=0.86,      # [-]
    eta_ext=0.70,        # [-]
    eta_thermal=30.0,    # [-]
    eta_hum=15.0,  # [-]
)