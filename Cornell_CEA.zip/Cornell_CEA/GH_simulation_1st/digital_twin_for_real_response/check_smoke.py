import numpy as np

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_params import DEFAULT_PARAMS as p
# from digital_twin_one_step_RK4 import simulate_one_step
from digital_twin_one_step_linear import simulate_one_step

from indoor_ODE import greenhouse_ode, compute_intermediates


def sample_case(rng: np.random.Generator):
    """
    State: x = [T_in, H_in, C_in, L_DLI]
    Dist:  d = [T_out, H_out, C_out, R_out]
    Ctrl:  u = [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]
    """

    # --- sample state (plausible ranges, adjust as you like)
    T_in = rng.uniform(10.0, 32.0)     # °C
    H_in = rng.uniform(3.0, 20.0)      # g/m^3
    C_in = rng.uniform(0.6, 2.2)       # g/m^3
    L_DLI = rng.uniform(0.0, 25.0)     # mol/m^2
    x0 = np.array([T_in, H_in, C_in, L_DLI], dtype=float)

    # --- sample disturbances
    T_out = rng.uniform(0.0, 35.0)     # °C
    H_out = rng.uniform(2.0, 18.0)     # g/m^3
    C_out = rng.uniform(0.6, 1.8)      # g/m^3
    R_out = rng.uniform(0.0, 900.0)    # W/m^2
    d = np.array([T_out, H_out, C_out, R_out], dtype=float)

    # --- sample controls in [0,1]
    u = rng.uniform(0.0, 1.0, size=8).astype(float)

    # simple coupling: pads usually need fan
    if u[3] > 0.1 and u[1] < 0.2:
        u[1] = 0.2

    # avoid humidifier and dehumidifier both maxed (optional)
    if u[6] > 0.7 and u[7] > 0.7:
        if rng.random() < 0.5:
            u[6] *= 0.2
        else:
            u[7] *= 0.2

    return x0, u, d


def check_one(x0, u, d):
    """
    Returns: issues(list[str]), x1, xdot0
    """
    # derivative at t=0 (for "fast response" warnings)
    xdot0 = greenhouse_ode(0.0, x0, u, d, p)

    # one-step 5 min simulation
    res = simulate_one_step(x_ini=x0, u=u, d=d, p=p, horizon_s=360.0, dt_s=5.0)
    x1 = res.x1

    issues = []

    # --- hard failures
    if not np.all(np.isfinite(x1)):
        issues.append("nonfinite")

    T1, H1, C1, L1 = x1

    if H1 < -1e-6:
        issues.append("negative_H")
    if C1 < -1e-6:
        issues.append("negative_C")
    if L1 < -1e-6:
        issues.append("negative_L")

    # --- broad plausibility bounds (tune for your greenhouse)
    if not (-10.0 <= T1 <= 60.0):
        issues.append("T_out_of_bounds")
    if not (0.0 <= H1 <= 40.0):
        issues.append("H_out_of_bounds")
    if not (0.0 <= C1 <= 5.0):
        issues.append("C_out_of_bounds")
    if not (0.0 <= L1 <= 80.0):
        issues.append("L_out_of_bounds")

    # --- supersaturation (soft check)
    inter1 = compute_intermediates(x1, u, d, p)
    if H1 > 1.10 * inter1.H_in_sat:
        issues.append("supersat")

    # --- "too fast" warnings (soft check, per-hour based on xdot at start)
    dT_per_h = xdot0[0] * 3600.0
    dH_per_h = xdot0[1] * 3600.0

    if abs(dT_per_h) > 50.0:
        issues.append("fast_T")
    if abs(dH_per_h) > 50.0:
        issues.append("fast_H")

    return issues, x1, xdot0


def main():
    rng = np.random.default_rng(42)
    N = 200

    issue_counts = {}
    examples = []

    dT_list, dH_list, dC_list = [], [], []

    for _ in range(N):
        x0, u, d = sample_case(rng)
        issues, x1, xdot0 = check_one(x0, u, d)

        dx = x1 - x0
        dT_list.append(dx[0])
        dH_list.append(dx[1])
        dC_list.append(dx[2])

        for it in issues:
            issue_counts[it] = issue_counts.get(it, 0) + 1

        # store a few representative "bad" cases
        if issues and len(examples) < 8:
            examples.append((issues, x0, u, d, x1, xdot0))

    print("\n================ Smoke Test Summary ================")
    print(f"Runs: {N}")
    if not issue_counts:
        print("No issues found ✅ (under current thresholds).")
    else:
        for k in sorted(issue_counts, key=lambda kk: (-issue_counts[kk], kk)):
            print(f"{k:>16s}: {issue_counts[k]}")

    def pct(arr, qs):
        arr = np.array(arr, dtype=float)
        return np.percentile(arr, qs)

    print("\nΔ over 5 minutes (percentiles):")
    print("  ΔT [°C]   :", pct(dT_list, [0, 5, 25, 50, 75, 95, 100]))
    print("  ΔH [g/m³] :", pct(dH_list, [0, 5, 25, 50, 75, 95, 100]))
    print("  ΔC [g/m³] :", pct(dC_list, [0, 5, 25, 50, 75, 95, 100]))

    if examples:
        print("\n================ Example flagged cases ================")
        for i, (issues, x0, u, d, x1, xdot0) in enumerate(examples, 1):
            print(f"\n--- Example {i}: {issues}")
            print("x0   =", x0)
            print("u    =", u)
            print("d    =", d)
            print("x1   =", x1)
            print("xdot0=", xdot0, " (per hour =", xdot0 * 3600.0, ")")


if __name__ == "__main__":
    main()
