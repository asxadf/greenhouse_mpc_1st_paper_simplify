"""
One-step simulation over 5 minutes (300 s).

Given:
- initial state x_ini
- constant control input u (over the 5-min interval)
- constant disturbance d (over the 5-min interval)

Computes x_end after 300 seconds.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from indoor_ODE import greenhouse_ode
from digital_twin_params import GreenhouseParams, DEFAULT_PARAMS

ArrayF = NDArray[np.float64]

# ============================================================
# EDIT THESE (easy typing spot)
# ============================================================
# State:                    x = [T_in,  H_in,  C_in,  L_DLI]
X_INI: ArrayF = np.array(
    [19.00, 10.20, 1.08, 0.00],  # <-- fill in
    dtype=np.float64,
)

# Control:              u = [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]
U: ArrayF = np.array(
    [1.00, 0.00, 0.00, 0.00, 0.00, 1.00, 0.00, 0.00],  # <-- fill in
    dtype=np.float64,
)

# Disturbance:          d = [T_out, H_out, C_out, R_out]
D: ArrayF = np.array(
    [19.00, 10.20, 1.08, 0.00],  # <-- fill in
    dtype=np.float64,
)
# ============================================================


@dataclass(frozen=True, slots=True)
class StepResult:
    t0: float
    t1: float
    x0: ArrayF
    x1: ArrayF


def rk4_step(
    f,
    t: float,
    x: ArrayF,
    h: float,
    u: ArrayF,
    d: ArrayF,
    p: GreenhouseParams,
) -> ArrayF:
    k1 = f(t, x, u, d, p)
    k2 = f(t + 0.5 * h, x + 0.5 * h * k1, u, d, p)
    k3 = f(t + 0.5 * h, x + 0.5 * h * k2, u, d, p)
    k4 = f(t + h, x + h * k3, u, d, p)
    return x + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)


def simulate_one_step(
    x_ini: ArrayF,
    u: ArrayF,
    d: ArrayF,
    p: GreenhouseParams = DEFAULT_PARAMS,
    horizon_s: float = 300.0,
    dt_s: float = 5.0,
    t0: float = 0.0,
) -> StepResult:
    """
    Integrate from t0 to t0+horizon_s using fixed-step RK4.

    dt_s=5s gives 60 steps over 300s.
    If horizon_s is not an exact multiple of dt_s, a final smaller RK4 step is used.
    """
    x = np.asarray(x_ini, dtype=np.float64).copy()
    u = np.asarray(u, dtype=np.float64).copy()
    d = np.asarray(d, dtype=np.float64).copy()

    if x.shape != (4,):
        raise ValueError(f"x_ini must be shape (4,), got {x.shape}")
    if u.shape != (8,):
        raise ValueError(f"u must be shape (8,), got {u.shape}")
    if d.shape != (4,):
        raise ValueError(f"d must be shape (4,), got {d.shape}")
    if dt_s <= 0 or horizon_s <= 0:
        raise ValueError("dt_s and horizon_s must be positive")

    t = float(t0)

    n_full = int(np.floor(horizon_s / dt_s))
    remainder = float(horizon_s - n_full * dt_s)

    for _ in range(n_full):
        x = rk4_step(greenhouse_ode, t, x, dt_s, u, d, p)
        t += dt_s

    if remainder > 1e-12:
        x = rk4_step(greenhouse_ode, t, x, remainder, u, d, p)
        t += remainder

    return StepResult(t0=t0, t1=t, x0=np.asarray(x_ini, dtype=np.float64), x1=x)


def _assert_no_nan(name: str, arr: ArrayF) -> None:
    if np.any(np.isnan(arr)):
        raise RuntimeError(
            f"{name} contains NaN; please fill in values at the top of simulation.py."
        )


def main() -> None:
    x_ini = X_INI
    u = U
    d = D

    _assert_no_nan("X_INI", x_ini)
    _assert_no_nan("U", u)
    _assert_no_nan("D", d)

    result = simulate_one_step(
        x_ini=x_ini,
        u=u,
        d=d,
        p=DEFAULT_PARAMS,
        horizon_s=300.0,
        dt_s=5.0,
    )
    print("t0:", result.t0)
    print("t1:", result.t1)
    print("x0:", result.x0)
    print("x1:", result.x1)


if __name__ == "__main__":
    main()
