# =========================
# file: gh_mpc_main_v2.py
# =========================
"""
Receding-horizon linear MPC runner + RK4 validation + main.py-style stacked plots
+ cost pie charts (resource cost + tracking cost).

Plot units:
- CO2: ppm
- Humidity: Relative Humidity (%)

Outputs:
  mpc_states.csv, mpc_controls.csv, mpc_disturbances.csv, mpc_aux.csv
  <prefix>summary.png (stacked plot)
  <prefix>summary_pies.png (two pie charts)

Uses x_ini = [18.9, 11.75, 0.796, 0.0] for [T_in, H_in, C_in, L_DLI].

Global simulation length:
  SIM_DAYS is the only source of truth for simulation duration.

DLI reset:
  L^{DLI} is forced to reset to 0 at the day boundary (after 23:59),
  i.e., whenever the next timestamp is on a new calendar date.
"""

from __future__ import annotations

from typing import Optional, Tuple
import time as _time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_one_step_RK4 import simulate_one_step
from gh_mpc_constants import MPCParams, StateBounds
from gh_mpc_model import MPCController, load_linear_model, linear_one_step, clamp_u_seq


# ------------------------ Global sim config ------------------------
SIM_DAYS: int = 12


def set_sim_days(days: int) -> None:
    """
    Set the global simulation length in days.

    This is the only supported way to control simulation duration in this module.
    """
    global SIM_DAYS
    SIM_DAYS = int(days)
    if SIM_DAYS <= 0:
        raise ValueError("SIM_DAYS must be >= 1.")


# ------------------------ Unit conversions ------------------------
_P_ATM_PA = 101_325.0
_R_UNIV = 8.314462618  # J/(mol*K)
_MW_CO2 = 44.01  # g/mol
_R_V = 461.5  # J/(kg*K) for water vapor


def _sat_vapor_pressure_pa(T_c: np.ndarray) -> np.ndarray:
    """
    Tetens formula. T in °C, returns saturation vapor pressure in Pa.
    """
    T = np.asarray(T_c, dtype=float)
    return 610.94 * np.exp((17.625 * T) / (T + 243.04))


def abs_humidity_gm3_to_rh_pct(H_gm3: np.ndarray, T_c: np.ndarray) -> np.ndarray:
    """
    Absolute humidity (g/m^3) -> RH (%), using ideal-gas vapor density.
    """
    H = np.asarray(H_gm3, dtype=float)
    T = np.asarray(T_c, dtype=float)
    T_k = T + 273.15

    e_s = _sat_vapor_pressure_pa(T)  # Pa
    rho_sat_kg_m3 = e_s / (_R_V * T_k)  # kg/m^3
    rho_sat_g_m3 = rho_sat_kg_m3 * 1000.0

    rh = 100.0 * (H / np.maximum(rho_sat_g_m3, 1e-12))
    return np.clip(rh, 0.0, 100.0)


def co2_gm3_to_ppm(C_gm3: np.ndarray, T_c: np.ndarray, P_pa: float = _P_ATM_PA) -> np.ndarray:
    """
    CO2 concentration (g/m^3) -> ppm (mole fraction * 1e6), ideal gas.
    """
    C = np.asarray(C_gm3, dtype=float)
    T = np.asarray(T_c, dtype=float)
    T_k = T + 273.15

    mol_m3 = C / _MW_CO2  # (g/m^3) / (g/mol) = mol/m^3
    x = mol_m3 * (_R_UNIV * T_k) / P_pa  # mole fraction
    ppm = x * 1e6
    return np.maximum(ppm, 0.0)


# ------------------------ IO helpers ------------------------
def read_outdoor_csv(path: str, date_format: str = "%m/%d/%y %H:%M") -> pd.DataFrame:
    """
    Robust reader for your outdoor prediction/realization CSVs.
    Normalizes to columns: [T_out, H_out, C_out, R_out] with datetime index.
    """
    try:
        df = pd.read_csv(path, encoding="utf-8", engine="python")
    except UnicodeDecodeError:
        df = pd.read_csv(path, encoding="latin1", engine="python")

    rename = {
        "DATE Time": "DATE Time",
        "Date Time": "DATE Time",
        "DATE_Time": "DATE Time",
        "T Outdoor(C)": "T_Outdoor(C)",
        "T_Outdoor (C)": "T_Outdoor(C)",
        "T_Outdoor(C)": "T_Outdoor(C)",
        "H Outdoor(g/m3)": "H_Outdoor(g/m3)",
        "H_Outdoor (g/m3)": "H_Outdoor(g/m3)",
        "H_Outdoor(g/m3)": "H_Outdoor(g/m3)",
        "CO2 Outdoor(g/m3)": "CO2_Outdoor(g/m3)",
        "CO2_Outdoor (g/m3)": "CO2_Outdoor(g/m3)",
        "CO2_Outdoor(g/m3)": "CO2_Outdoor(g/m3)",
        "Radiation Outdoor(w/m2)": "Radiation_Outdoor(w/m2)",
        "Radiation_Outdoor (w/m2)": "Radiation_Outdoor(w/m2)",
        "Radiation_Outdoor(w/m2)": "Radiation_Outdoor(w/m2)",
    }
    df = df.rename(columns={c: rename.get(c, c) for c in df.columns})

    required = [
        "DATE Time",
        "T_Outdoor(C)",
        "H_Outdoor(g/m3)",
        "CO2_Outdoor(g/m3)",
        "Radiation_Outdoor(w/m2)",
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(f"Missing columns in {path}: {missing}")

    df["DATE Time"] = pd.to_datetime(df["DATE Time"], format=date_format, errors="raise")
    df = df.sort_values("DATE Time").reset_index(drop=True)

    df = df.rename(
        columns={
            "T_Outdoor(C)": "T_out",
            "H_Outdoor(g/m3)": "H_out",
            "CO2_Outdoor(g/m3)": "C_out",
            "Radiation_Outdoor(w/m2)": "R_out",
        }
    )
    df = df.set_index("DATE Time")
    return df[["T_out", "H_out", "C_out", "R_out"]].astype(float)


def _slice_horizon(df: pd.DataFrame, start_idx: int, K: int) -> np.ndarray:
    block = df.iloc[start_idx : start_idx + K].to_numpy(dtype=np.float64)
    if block.shape[0] < K:
        pad = np.repeat(block[-1:, :], K - block.shape[0], axis=0)
        block = np.vstack([block, pad])
    return block


def _format_eta(done: int, total: int, start_t: float) -> str:
    if done <= 0:
        return "ETA=?"
    elapsed = _time.time() - start_t
    rate = elapsed / done
    remaining = (total - done) * rate
    return f"ETA={remaining:6.1f}s"


def _next_timestamp(index: pd.DatetimeIndex, k: int, dt_s: float) -> pd.Timestamp:
    if k + 1 < len(index):
        return pd.Timestamp(index[k + 1])
    return pd.Timestamp(index[k]) + pd.Timedelta(seconds=float(dt_s))


def _apply_dli_midnight_reset(
    ts: pd.Timestamp,
    ts_next: pd.Timestamp,
    x_next: np.ndarray,
) -> None:
    if ts_next.date() != ts.date():
        x_next[3] = 0.0


# ------------------------ MPC runner ------------------------
def run_mpc(
    pred_csv: str = "data_outdoor_prediction.csv",
    real_csv: str = "data_outdoor_realization.csv",
    *,
    K: Optional[int] = None,
    gamma: Optional[float] = None,
    solver_name: str = "osqp",
    tee: bool = False,
    progress: bool = True,
    model_npz: str = "linear_model_matrices.npz",
    dt_integrator_s: float = 5.0,
    x_ini: Optional[np.ndarray] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Receding-horizon MPC:
      - optimize using predicted disturbances
      - simulate RK4 plant using realized disturbances

    Simulation length is controlled ONLY by the module-level SIM_DAYS.

    Returns:
      df_states, df_controls, df_aux, df_disturbances
    """
    params = MPCParams()
    if K is not None:
        params = MPCParams(**{**params.__dict__, "K": int(K)})
    if gamma is not None:
        params = MPCParams(**{**params.__dict__, "gamma": float(gamma)})

    bounds = StateBounds()
    model = load_linear_model(model_npz)
    ctrl = MPCController(model=model, params=params, bounds=bounds, solver_name=solver_name)

    df_pred = read_outdoor_csv(pred_csv)
    df_real = read_outdoor_csv(real_csv)

    common = df_pred.index.intersection(df_real.index)
    if common.empty:
        raise RuntimeError("Prediction/realization CSVs have no overlapping timestamps.")
    df_pred = df_pred.loc[common]
    df_real = df_real.loc[common]

    steps_per_day = int(round(24 * 3600 / params.dt_s))
    total = int(SIM_DAYS * steps_per_day)
    total = min(total, len(df_real))

    # x = [T_in, H_in, C_in, L_DLI]
    x = (
        np.array([18.9, 11.75, 0.796, 0.0], dtype=np.float64)
        if x_ini is None
        else np.asarray(x_ini, dtype=np.float64).reshape(4,)
    )

    warm: Optional[np.ndarray] = None  # (K,8)

    states, controls, disturbances, aux = [], [], [], []
    start_t = _time.time()

    idx = pd.DatetimeIndex(df_real.index)

    for k in range(total):
        ts = pd.Timestamp(idx[k])
        ts_next = _next_timestamp(idx, k, params.dt_s)

        d_pred_h = _slice_horizon(df_pred, k, params.K)
        d0_pred = d_pred_h[0, :]
        d0_real = df_real.iloc[k].to_numpy(dtype=np.float64)

        if warm is not None:
            warm = clamp_u_seq(warm)

        u0, u_seq, _x_seq, v_seq, status, obj = ctrl.solve(
            x0=x,
            d_pred=d_pred_h,
            t0=ts,
            warm_u_seq=warm,
            tee=tee,
        )

        warm = np.vstack([u_seq[1:, :], u_seq[-1:, :]])

        x1_lin_pred = linear_one_step(model, x, u0, d0_pred)

        rk = simulate_one_step(
            x_ini=x,
            u=u0,
            d=d0_real,
            horizon_s=params.dt_s,
            dt_s=dt_integrator_s,
            t0=0.0,
        )
        x1_real = np.asarray(rk.x1, dtype=np.float64)

        _apply_dli_midnight_reset(ts, ts_next, x1_real)
        _apply_dli_midnight_reset(ts, ts_next, x1_lin_pred)

        err = x1_lin_pred - x1_real
        slack_max = float(np.nanmax(v_seq)) if np.isfinite(v_seq).any() else float("nan")

        states.append(
            {
                "k": k,
                "DATE Time": ts,
                "T_in": x[0],
                "H_in": x[1],
                "C_in": x[2],
                "L_DLI": x[3],
                "T_in_next_real": x1_real[0],
                "H_in_next_real": x1_real[1],
                "C_in_next_real": x1_real[2],
                "L_DLI_next_real": x1_real[3],
                "T_in_next_lin_pred": x1_lin_pred[0],
                "H_in_next_lin_pred": x1_lin_pred[1],
                "C_in_next_lin_pred": x1_lin_pred[2],
                "L_DLI_next_lin_pred": x1_lin_pred[3],
            }
        )

        controls.append(
            {
                "k": k,
                "DATE Time": ts,
                "U_heat": u0[0],
                "U_fan": u0[1],
                "U_nat": u0[2],
                "U_pad": u0[3],
                "U_dos": u0[4],
                "U_LED": u0[5],
                "U_hum": u0[6],
                "U_dehum": u0[7],
                "status": status,
            }
        )

        disturbances.append(
            {
                "k": k,
                "DATE Time": ts,
                "T_out_pred": d0_pred[0],
                "H_out_pred": d0_pred[1],
                "C_out_pred": d0_pred[2],
                "R_out_pred": d0_pred[3],
                "T_out_real": d0_real[0],
                "H_out_real": d0_real[1],
                "C_out_real": d0_real[2],
                "R_out_real": d0_real[3],
            }
        )

        aux.append(
            {
                "k": k,
                "DATE Time": ts,
                "objective": obj,
                "solver_status": status,
                "err_T": err[0],
                "err_H": err[1],
                "err_C": err[2],
                "err_L": err[3],
                "slack_T0": float(v_seq[0, 0]) if np.isfinite(v_seq[0, 0]) else float("nan"),
                "slack_H0": float(v_seq[0, 1]) if np.isfinite(v_seq[0, 1]) else float("nan"),
                "slack_C0": float(v_seq[0, 2]) if np.isfinite(v_seq[0, 2]) else float("nan"),
                "slack_max": slack_max,
            }
        )

        x = x1_real

        if progress and (k == 0 or (k + 1) % 24 == 0 or (k + 1) == total):
            print(
                f"[MPC] step {k+1:4d}/{total}  {_format_eta(k+1, total, start_t)}  "
                f"status={status}  slack_max={slack_max:.3g}",
                flush=True,
            )

    df_states = pd.DataFrame(states)
    df_controls = pd.DataFrame(controls)
    df_aux = pd.DataFrame(aux)
    df_dist = pd.DataFrame(disturbances)
    return df_states, df_controls, df_aux, df_dist


def save_outputs(
    df_states: pd.DataFrame,
    df_controls: pd.DataFrame,
    df_aux: pd.DataFrame,
    df_dist: pd.DataFrame,
    out_dir: str = ".",
    prefix: str = "mpc_",
) -> None:
    from pathlib import Path

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    df_states.to_csv(out / f"{prefix}states.csv", index=False)
    df_controls.to_csv(out / f"{prefix}controls.csv", index=False)
    df_dist.to_csv(out / f"{prefix}disturbances.csv", index=False)
    df_aux.to_csv(out / f"{prefix}aux.csv", index=False)

    print(f"Saved: {out / f'{prefix}states.csv'}")
    print(f"Saved: {out / f'{prefix}controls.csv'}")
    print(f"Saved: {out / f'{prefix}disturbances.csv'}")
    print(f"Saved: {out / f'{prefix}aux.csv'}")



# ------------------------ Violations ------------------------
def compute_state_band_violations(
    df_states: pd.DataFrame,
    *,
    bounds: Optional[StateBounds] = None,
) -> pd.DataFrame:
    """
    Compute state-band violations for T/H/CO2 in their native MPC units.

    Units:
      - Temperature: °C
      - Humidity: g/m^3 (absolute humidity)
      - CO2: g/m^3

    Returns a dataframe with per-timestep bounds and signed/unsigned violations.
    """
    from gh_mpc_constants import x_bounds_for_time, is_light_period

    b = bounds or StateBounds()

    df = df_states.copy()
    df["DATE Time"] = pd.to_datetime(df["DATE Time"])
    t = df["DATE Time"]

    T = df["T_in"].to_numpy(dtype=float)
    H = df["H_in"].to_numpy(dtype=float)
    C = df["C_in"].to_numpy(dtype=float)

    T_lo = np.empty_like(T)
    T_hi = np.empty_like(T)
    H_lo = np.empty_like(H)
    H_hi = np.empty_like(H)
    C_lo = np.empty_like(C)
    C_hi = np.empty_like(C)
    is_light = np.zeros((len(df),), dtype=bool)

    for i, ts in enumerate(t):
        lo, hi = x_bounds_for_time(ts.to_pydatetime(), b)
        T_lo[i], T_hi[i] = float(lo[0]), float(hi[0])
        H_lo[i], H_hi[i] = float(lo[1]), float(hi[1])
        C_lo[i], C_hi[i] = float(lo[2]), float(hi[2])
        is_light[i] = bool(is_light_period(ts.to_pydatetime()))

    def _signed(val: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
        out = np.zeros_like(val, dtype=float)
        out = np.where(val < lo, val - lo, out)
        out = np.where(val > hi, val - hi, out)
        return out

    T_v = _signed(T, T_lo, T_hi)
    H_v = _signed(H, H_lo, H_hi)
    C_v = _signed(C, C_lo, C_hi)

    df_out = pd.DataFrame(
        {
            "DATE Time": t,
            "is_light": is_light,
            "period": np.where(is_light, "light", "dark"),
            # Temperature (°C)
            "T_in_C": T,
            "T_lo_C": T_lo,
            "T_hi_C": T_hi,
            "T_violation_C": T_v,
            "T_violation_low_C": np.maximum(-T_v, 0.0),
            "T_violation_high_C": np.maximum(T_v, 0.0),
            "T_violation_mag_C": np.abs(T_v),
            # Humidity (g/m^3)
            "H_in_gm3": H,
            "H_lo_gm3": H_lo,
            "H_hi_gm3": H_hi,
            "H_violation_gm3": H_v,
            "H_violation_low_gm3": np.maximum(-H_v, 0.0),
            "H_violation_high_gm3": np.maximum(H_v, 0.0),
            "H_violation_mag_gm3": np.abs(H_v),
            # CO2 (g/m^3)
            "CO2_in_gm3": C,
            "CO2_lo_gm3": C_lo,
            "CO2_hi_gm3": C_hi,
            "CO2_violation_gm3": C_v,
            "CO2_violation_low_gm3": np.maximum(-C_v, 0.0),
            "CO2_violation_high_gm3": np.maximum(C_v, 0.0),
            "CO2_violation_mag_gm3": np.abs(C_v),
        }
    )

    df_out["any_violation"] = (
        (df_out["T_violation_mag_C"] > 0.0)
        | (df_out["H_violation_mag_gm3"] > 0.0)
        | (df_out["CO2_violation_mag_gm3"] > 0.0)
    )
    df_out["total_violation_mag"] = (
        df_out["T_violation_mag_C"]
        + df_out["H_violation_mag_gm3"]
        + df_out["CO2_violation_mag_gm3"]
    )
    return df_out


def print_violation_summary(df_viol: pd.DataFrame, *, top_n: int = 12) -> None:
    """
    Print a concise summary + worst timestamps by total violation magnitude.
    """
    df = df_viol.copy()
    n = len(df)
    n_bad = int(df["any_violation"].sum())
    print("\n=== State band violations (native units) ===")
    print("Units: T in °C, H in g/m^3, CO2 in g/m^3")
    print(f"Timesteps: {n}   Violating steps: {n_bad} ({(100.0*n_bad/max(n,1)):.2f}%)")

    def _stats(prefix: str, mag_col: str, signed_col: str) -> None:
        mag = df[mag_col].to_numpy(dtype=float)
        signed = df[signed_col].to_numpy(dtype=float)
        below = int(np.sum(signed < 0))
        above = int(np.sum(signed > 0))
        mx = float(np.nanmax(mag)) if np.isfinite(mag).any() else float("nan")
        print(f"- {prefix}: below={below}, above={above}, max|violation|={mx:.4g}")

    _stats("T (°C)", "T_violation_mag_C", "T_violation_C")
    _stats("H (g/m^3)", "H_violation_mag_gm3", "H_violation_gm3")
    _stats("CO2 (g/m^3)", "CO2_violation_mag_gm3", "CO2_violation_gm3")

    if n_bad == 0:
        return

    worst = df.sort_values("total_violation_mag", ascending=False).head(int(top_n))
    cols = [
        "DATE Time",
        "period",
        "T_in_C",
        "T_lo_C",
        "T_hi_C",
        "T_violation_C",
        "H_in_gm3",
        "H_lo_gm3",
        "H_hi_gm3",
        "H_violation_gm3",
        "CO2_in_gm3",
        "CO2_lo_gm3",
        "CO2_hi_gm3",
        "CO2_violation_gm3",
        "total_violation_mag",
    ]
    with pd.option_context("display.width", 180, "display.max_columns", None):
        print("\nWorst violations (sorted by total_violation_mag):")
        print(worst[cols].to_string(index=False))


# ------------------------ Plotting ------------------------
def plot_outputs(
    df_states: pd.DataFrame,
    df_controls: pd.DataFrame,
    df_dist: pd.DataFrame,
    df_aux: pd.DataFrame,  # kept for signature compatibility
    out_png: str = "mpc_summary.png",
) -> None:
    """
    main.py-style stacked figure:
      disturbances -> controls -> states (with bands) -> DLI (daily-reset)
    + pie charts (resource cost + tracking cost)

    Plot units:
      - CO2: ppm
      - Humidity: RH (%)
    """
    from matplotlib import gridspec, rcParams
    from matplotlib.ticker import FuncFormatter
    import matplotlib.dates as mdates

    from gh_mpc_constants import (
        MPCParams,
        StateBounds,
        x_bounds_for_time,
        x_star_for_time,
        stage_energy_coeffs,
    )

    rcParams["font.family"] = "Helvetica"
    rcParams["font.sans-serif"] = ["Helvetica", "Arial", "DejaVu Sans"]

    def _two_line_time_formatter(x: float, _pos: int) -> str:
        dt = mdates.num2date(x)
        return f"{dt:%H:%M}\n{dt:%m-%d}"

    def _one_decimal(x: float, _pos: int) -> str:
        return f"{x:.1f}"

    df_states = df_states.copy()
    df_controls = df_controls.copy()
    df_dist = df_dist.copy()

    df_states["DATE Time"] = pd.to_datetime(df_states["DATE Time"])
    df_controls["DATE Time"] = pd.to_datetime(df_controls["DATE Time"])
    df_dist["DATE Time"] = pd.to_datetime(df_dist["DATE Time"])

    t_state = df_states["DATE Time"]
    t_ctrl = df_controls["DATE Time"]
    t_real = df_dist["DATE Time"]

    # ---- Convert units for plotting ----
    T_in = df_states["T_in"].to_numpy(dtype=float)
    H_in_abs = df_states["H_in"].to_numpy(dtype=float)
    C_in_abs = df_states["C_in"].to_numpy(dtype=float)

    H_in_rh = abs_humidity_gm3_to_rh_pct(H_in_abs, T_in)
    C_in_ppm = co2_gm3_to_ppm(C_in_abs, T_in)

    T_out = df_dist["T_out_real"].to_numpy(dtype=float)
    H_out_abs = df_dist["H_out_real"].to_numpy(dtype=float)
    C_out_abs = df_dist["C_out_real"].to_numpy(dtype=float)

    H_out_rh = abs_humidity_gm3_to_rh_pct(H_out_abs, T_out)
    C_out_ppm = co2_gm3_to_ppm(C_out_abs, T_out)

    # ---- Columns / titles ----
    dist_cols_plot = ["T_out_real", "H_out_RH", "C_out_ppm", "R_out_real"]
    dist_series = {
        "T_out_real": df_dist["T_out_real"].to_numpy(dtype=float),
        "H_out_RH": H_out_rh,
        "C_out_ppm": C_out_ppm,
        "R_out_real": df_dist["R_out_real"].to_numpy(dtype=float),
    }
    dist_labels = [r"$T^{out}$ (°C)", r"$RH^{out}$ (%)", r"$CO_2^{out}$ (ppm)", r"$R^{out}$ (W/m$^2$)"]
    dist_titles = ["Outdoor Temperature", "Outdoor Relative Humidity", "Outdoor CO2", "Outdoor Radiation"]

    ctrl_cols = ["U_heat", "U_fan", "U_nat", "U_pad", "U_dos", "U_LED", "U_hum", "U_dehum"]
    ctrl_labels = [
        r"$U^{heat}$", r"$U^{fan}$", r"$U^{nat}$", r"$U^{pad}$",
        r"$U^{dos}$", r"$U^{LED}$", r"$U^{hum}$", r"$U^{dehum}$",
    ]
    ctrl_titles = [
        "Heating", "Fan", "Natural Vent", "Pad Cooling",
        "CO2 dosing", "LEDs", "Humidifiers", "Dehumidifiers",
    ]

    state_cols_plot = ["T_in", "H_in_RH", "C_in_ppm", "L_DLI"]
    state_series = {
        "T_in": df_states["T_in"].to_numpy(dtype=float),
        "H_in_RH": H_in_rh,
        "C_in_ppm": C_in_ppm,
        "L_DLI": df_states["L_DLI"].to_numpy(dtype=float),
    }
    state_labels = [r"$T^{in}$ (°C)", r"$RH^{in}$ (%)", r"$CO_2^{in}$ (ppm)", r"$L^{DLI}$ (mol/m$^2$)"]
    state_titles = ["Indoor Temperature", "Indoor Relative Humidity", "Indoor CO2", "Daily Light Integral (state)"]

    # ---- Bands + refs (convert bounds to RH% and ppm) ----
    b = StateBounds()
    Tmin_arr, Tmax_arr = [], []
    Hmin_abs_arr, Hmax_abs_arr = [], []
    Cmin_abs_arr, Cmax_abs_arr = [], []
    Lstar_arr = []
    for ts in t_state:
        lo, hi = x_bounds_for_time(ts.to_pydatetime(), b)
        Tmin_arr.append(lo[0]); Tmax_arr.append(hi[0])
        Hmin_abs_arr.append(lo[1]); Hmax_abs_arr.append(hi[1])
        Cmin_abs_arr.append(lo[2]); Cmax_abs_arr.append(hi[2])
        Lstar_arr.append(x_star_for_time(ts.to_pydatetime(), b)[3])

    Tmin_arr = np.asarray(Tmin_arr, dtype=float)
    Tmax_arr = np.asarray(Tmax_arr, dtype=float)
    Hmin_abs_arr = np.asarray(Hmin_abs_arr, dtype=float)
    Hmax_abs_arr = np.asarray(Hmax_abs_arr, dtype=float)
    Cmin_abs_arr = np.asarray(Cmin_abs_arr, dtype=float)
    Cmax_abs_arr = np.asarray(Cmax_abs_arr, dtype=float)
    Lstar_arr = np.asarray(Lstar_arr, dtype=float)

    Hmin_rh_arr = abs_humidity_gm3_to_rh_pct(Hmin_abs_arr, T_in)
    Hmax_rh_arr = abs_humidity_gm3_to_rh_pct(Hmax_abs_arr, T_in)

    Cmin_ppm_arr = co2_gm3_to_ppm(Cmin_abs_arr, T_in)
    Cmax_ppm_arr = co2_gm3_to_ppm(Cmax_abs_arr, T_in)

    # ---- DLI: daily-reset ----
    ts_ser = pd.to_datetime(t_state)
    l_dli = df_states["L_DLI"].astype(float)
    dli_daily = l_dli.groupby(ts_ser.dt.date).transform(lambda s: s - float(s.iloc[0]))
    dli_ref = pd.Series(Lstar_arr, index=t_state)
    DLI_TARGET = 26.0

    # ---- Style ----
    band_color = "#1581BF"
    band_alpha = 0.20
    COL_U = "#E78B48"
    COL_STATE = "#1C6EA4"
    COL_OUT = "#BF124D"

    # ======== Figure 1: stacked time-series ========
    total_rows = len(dist_cols_plot) + len(ctrl_cols) + len(state_cols_plot) + 1
    fig = plt.figure(figsize=(12, 38), constrained_layout=True)
    gs = gridspec.GridSpec(total_rows, 1, figure=fig)

    axes = []
    row = 0
    share = None

    # Disturbances
    for key, title, yl in zip(dist_cols_plot, dist_titles, dist_labels):
        ax = fig.add_subplot(gs[row, 0], sharex=share)
        ax.plot(t_real, dist_series[key], color=COL_OUT, alpha=1.0, linewidth=0.55)
        ax.set_ylabel(yl)
        ax.text(0.01, 0.92, title, transform=ax.transAxes, ha="left", va="top", fontsize=10)

        if key in {"H_out_RH", "C_out_ppm"}:
            ax.yaxis.set_major_formatter(FuncFormatter(_one_decimal))

        ax.grid(True, linestyle="--", linewidth=0.5)
        axes.append(ax)
        row += 1

    # Controls
    for col, title, yl in zip(ctrl_cols, ctrl_titles, ctrl_labels):
        ax = fig.add_subplot(gs[row, 0], sharex=share)
        if share is None:
            share = ax
        ax.plot(t_ctrl, df_controls[col], color=COL_U, alpha=1.0, linewidth=0.7)
        ax.set_ylim(-0.02, 1.02)
        ax.set_yticks([0.0, 0.5, 1.0])
        ax.yaxis.set_major_formatter(FuncFormatter(_one_decimal))
        ax.set_ylabel(yl)
        ax.text(0.01, 0.92, title, transform=ax.transAxes, ha="left", va="top", fontsize=10)
        ax.grid(True, linestyle="--", linewidth=0.5)
        axes.append(ax)
        row += 1

    # States + bands
    for i, (key, title, yl) in enumerate(zip(state_cols_plot, state_titles, state_labels)):
        ax = fig.add_subplot(gs[row, 0], sharex=share)
        ax.plot(t_state, state_series[key], color=COL_STATE, alpha=1.0, linewidth=0.75)
        ax.set_ylabel(yl)
        ax.text(0.01, 0.92, title, transform=ax.transAxes, ha="left", va="top", fontsize=10)
        ax.grid(True, linestyle="--", linewidth=0.5)

        if i == 0:  # T
            ax.fill_between(t_state, Tmin_arr, Tmax_arr, alpha=band_alpha, linewidth=0, facecolor=band_color)
        elif i == 1:  # RH
            ax.fill_between(t_state, Hmin_rh_arr, Hmax_rh_arr, alpha=band_alpha, linewidth=0, facecolor=band_color)
            ax.set_ylim(0.0, 100.0)
            ax.yaxis.set_major_formatter(FuncFormatter(_one_decimal))
        elif i == 2:  # CO2 ppm
            ax.fill_between(t_state, Cmin_ppm_arr, Cmax_ppm_arr, alpha=band_alpha, linewidth=0, facecolor=band_color)
            ax.yaxis.set_major_formatter(FuncFormatter(_one_decimal))

        axes.append(ax)
        row += 1

    # DLI subplot
    ax = fig.add_subplot(gs[row, 0], sharex=share)
    ax.plot(t_state, dli_daily.values, color=COL_STATE, alpha=1.0, linewidth=0.9, label="DLI (cum. daily)")
    ax.plot(t_state, dli_ref.values, color=COL_U, alpha=0.9, linewidth=0.9, linestyle="--", label="DLI* (ref)")
    ax.axhline(DLI_TARGET, linestyle=":", linewidth=1.0, color=COL_OUT, label=f"Target = {DLI_TARGET:g}")
    ax.set_ylabel(r"DLI (mol/m$^2$)")
    ax.text(0.01, 0.42, "Daily Light Integral", transform=ax.transAxes, ha="left", va="top", fontsize=10)
    ymax = max(DLI_TARGET * 1.2, float(np.nanmax(dli_daily.values) if len(dli_daily) else DLI_TARGET))
    ax.set_ylim(0.0, ymax)
    ax.grid(True, linestyle="--", linewidth=0.5)
    ax.legend(loc="upper left", fontsize=8, frameon=False)
    axes.append(ax)

    for a in axes[:-1]:
        a.tick_params(labelbottom=False)

    axes[-1].set_xlabel("Time")
    axes[-1].xaxis.set_major_formatter(FuncFormatter(_two_line_time_formatter))
    axes[-1].xaxis.set_major_locator(mdates.AutoDateLocator(minticks=6, maxticks=12))
    fig.suptitle("Greenhouse MPC — Outdoor Disturbances, Controls, and States", fontsize=14)

    fig.savefig(out_png, dpi=200)
    print(f"Saved plot: {out_png}")

    # ======== Figure 2: nicer pie charts ========
    def _nice_pie(
        axp: plt.Axes,
        values: np.ndarray,
        labels: list[str],
        title: str,
        *,
        min_frac_other: float = 0.03,
        autopct_min_pct: float = 4.0,
    ) -> None:
        v = np.asarray(values, dtype=float)
        lab = list(labels)

        mask = np.isfinite(v) & (v > 1e-10)
        v = v[mask]
        lab = [lab[i] for i in np.where(mask)[0]]

        total = float(v.sum())
        if total <= 0:
            axp.text(0.5, 0.5, "Total = $0", ha="center", va="center")
            axp.set_title(title)
            axp.axis("off")
            return

        frac = v / total
        small = frac < min_frac_other
        if np.any(small) and np.any(~small):
            other_val = float(v[small].sum())
            keep_val = v[~small]
            keep_lab = [lab[i] for i in np.where(~small)[0]]
            v = np.concatenate([keep_val, [other_val]])
            lab = keep_lab + ["Other"]

        total2 = float(v.sum())

        def _autopct(p: float) -> str:
            return f"{p:.1f}%" if p >= autopct_min_pct else ""

        wedges, _txt, _auto = axp.pie(
            v,
            labels=None,
            startangle=90,
            autopct=_autopct,
            pctdistance=0.72,
            wedgeprops={"linewidth": 0.9, "edgecolor": "white"},
        )
        axp.axis("equal")

        legend_lines = []
        for name, val in zip(lab, v):
            pct = 100.0 * float(val) / total2 if total2 > 0 else 0.0
            legend_lines.append(f"{name}: ${val:.2f} ({pct:.1f}%)")

        axp.legend(
            wedges,
            legend_lines,
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            fontsize=9,
            frameon=False,
        )
        axp.set_title(f"{title}\nTotal = ${total2:.2f}")

    params = MPCParams()
    c_u = stage_energy_coeffs(params)  # dollars/step per unit u

    Umat = df_controls[["U_heat", "U_fan", "U_nat", "U_pad", "U_dos", "U_LED", "U_hum", "U_dehum"]].to_numpy(dtype=float)
    energy_by_u = (Umat * c_u.reshape(1, -1)).sum(axis=0)

    energy_labels = [
        "Heat",
        "Fan",
        "Natural Vent",
        "Pad",
        "CO2 dosing",
        "LED",
        "Humidification",
        "Dehumidification",
    ]

    Xmat = df_states[["T_in", "H_in", "C_in", "L_DLI"]].to_numpy(dtype=float)
    Xstar = np.vstack([x_star_for_time(ts.to_pydatetime(), b) for ts in t_state])
    dX = Xmat - Xstar

    track_totals = np.array(
        [
            params.lambda_T * np.sum(dX[:, 0] ** 2),
            params.lambda_H * np.sum(dX[:, 1] ** 2),
            params.lambda_C * np.sum(dX[:, 2] ** 2),
            params.lambda_L * np.sum(dX[:, 3] ** 2),
        ],
        dtype=float,
    )
    track_labels = [r"$(T-T^*)^2$", r"$(H-H^*)^2$", r"$(C-C^*)^2$", r"$(L-L^*)^2$"]

    pies_png = out_png[:-4] + "_pies.png" if out_png.lower().endswith(".png") else out_png + "_pies.png"

    fig2, ax2 = plt.subplots(1, 2, figsize=(13.0, 5.2), constrained_layout=True)
    _nice_pie(ax2[0], energy_by_u, energy_labels, "Resource cost breakdown")
    _nice_pie(ax2[1], track_totals, track_labels, "Tracking cost breakdown")
    fig2.suptitle("MPC Cost Composition (Undiscounted)", fontsize=14)
    fig2.savefig(pies_png, dpi=220)
    print(f"Saved pie charts: {pies_png}")

    plt.show(block=True)


# ------------------------ Main ------------------------
if __name__ == "__main__":
    import argparse
    from pathlib import Path

    ap = argparse.ArgumentParser()
    ap.add_argument("--pred-csv", type=str, default="data_outdoor_prediction.csv")
    ap.add_argument("--real-csv", type=str, default="data_outdoor_realization.csv")
    ap.add_argument("--model-npz", type=str, default="linear_model_matrices.npz")

    ap.add_argument("--sim-days", type=int, default=SIM_DAYS)
    ap.add_argument("--K", type=int, default=None)
    ap.add_argument("--gamma", type=float, default=None)
    ap.add_argument("--solver", type=str, default="osqp")
    ap.add_argument("--tee", action="store_true")
    ap.add_argument("--no-progress", dest="progress", action="store_false")
    ap.set_defaults(progress=True)

    ap.add_argument("--out-dir", type=str, default=".")
    ap.add_argument("--prefix", type=str, default="mpc_")

    ap.add_argument("--no-plot", dest="plot", action="store_false")
    ap.set_defaults(plot=True)

    ap.add_argument("--dt-integrator-s", type=float, default=5.0)

    args = ap.parse_args()

    set_sim_days(args.sim_days)

    df_states, df_controls, df_aux, df_dist = run_mpc(
        pred_csv=args.pred_csv,
        real_csv=args.real_csv,
        K=args.K,
        gamma=args.gamma,
        solver_name=args.solver,
        tee=args.tee,
        progress=args.progress,
        model_npz=args.model_npz,
        dt_integrator_s=args.dt_integrator_s,
        x_ini=None,
    )

    save_outputs(df_states, df_controls, df_aux, df_dist, out_dir=args.out_dir, prefix=args.prefix)

    # ---- Violations report (native units: °C, g/m^3, g/m^3) ----
    df_viol = compute_state_band_violations(df_states)
    viol_path = Path(args.out_dir) / f"{args.prefix}violations.csv"
    df_viol.to_csv(viol_path, index=False)
    print(f"Saved: {viol_path}")
    print_violation_summary(df_viol)

    if args.plot:

        plot_outputs(
            df_states=df_states,
            df_controls=df_controls,
            df_dist=df_dist,
            df_aux=df_aux,
            out_png=str(Path(args.out_dir) / f"{args.prefix}summary.png"),
        )
