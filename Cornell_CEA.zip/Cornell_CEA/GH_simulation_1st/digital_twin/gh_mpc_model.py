# =========================
# file: gh_mpc_model_v2.py
# =========================
"""
Linear MPC (QP) using learned (M,N,O,m) + soft bounds (slacks) on T/H/C.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

from gh_mpc_constants import (
    ArrayF,
    MPCParams,
    StateBounds,
    stage_energy_coeffs,
    x_bounds_for_time,
    x_star_for_time,
)

try:
    import cvxpy as cp
except Exception as e:  # pragma: no cover
    raise RuntimeError("cvxpy is required. Install with: pip install cvxpy osqp") from e


@dataclass(frozen=True, slots=True)
class LinearModel:
    M: ArrayF  # (4,4)
    N: ArrayF  # (4,8)
    O: ArrayF  # (4,4)
    m: ArrayF  # (4,)


def load_linear_model(npz_path: str | Path) -> LinearModel:
    data = np.load(Path(npz_path))
    M = np.asarray(data["M"], dtype=np.float64)
    N = np.asarray(data["N"], dtype=np.float64)
    O = np.asarray(data["O"], dtype=np.float64)
    m = np.asarray(data["m"], dtype=np.float64)

    if M.shape != (4, 4) or N.shape != (4, 8) or O.shape != (4, 4) or m.shape != (4,):
        raise ValueError(f"Bad shapes: M{M.shape}, N{N.shape}, O{O.shape}, m{m.shape}")

    return LinearModel(M=M, N=N, O=O, m=m)


def clamp01(a: ArrayF, eps: float = 1e-9) -> ArrayF:
    a = np.asarray(a, dtype=np.float64)
    a = np.where(a < eps, 0.0, a)
    a = np.where(a > 1.0 - eps, 1.0, a)
    return np.clip(a, 0.0, 1.0)


def clamp_u_seq(u_seq: ArrayF) -> ArrayF:
    return clamp01(u_seq)


class MPCController:
    """
    Build the QP once and update Parameters each step.

    Soft constraints for T/H/C:
        x_i >= lo_i - v_i
        x_i <= hi_i + v_i
        v_i >= 0
    Penalize v_i^2 in objective.

    L_DLI remains bounded only by wide sentinel bounds.
    """

    def __init__(
        self,
        model: LinearModel,
        params: MPCParams,
        bounds: StateBounds,
        solver_name: str = "osqp",
    ) -> None:
        self.model = model
        self.params = params
        self.bounds = bounds
        self.solver_name = solver_name.lower().strip()
        self._build_problem()

    def _build_problem(self) -> None:
        K = self.params.K
        gamma = self.params.gamma

        self.x = cp.Variable((4, K + 1))
        self.u = cp.Variable((8, K))
        self.v = cp.Variable((3, K + 1))  # slack for [T,H,C]

        self.x0_p = cp.Parameter(4)
        self.d_p = cp.Parameter((K, 4))
        self.xlo_p = cp.Parameter((K + 1, 4))
        self.xhi_p = cp.Parameter((K + 1, 4))
        self.xstar_p = cp.Parameter((K, 4))

        c_u = stage_energy_coeffs(self.params)

        constraints = [self.x[:, 0] == self.x0_p, self.v >= 0]
        obj = 0

        for k in range(K):
            constraints.append(
                self.x[:, k + 1]
                == self.model.M @ self.x[:, k]
                + self.model.N @ self.u[:, k]
                + self.model.O @ self.d_p[k, :]
                + self.model.m
            )

            # soft bounds for T/H/C
            constraints.append(self.x[0:3, k] >= self.xlo_p[k, 0:3] - self.v[:, k])
            constraints.append(self.x[0:3, k] <= self.xhi_p[k, 0:3] + self.v[:, k])

            # L_DLI wide sentinel bounds
            constraints.append(self.x[3, k] >= self.xlo_p[k, 3])
            constraints.append(self.x[3, k] <= self.xhi_p[k, 3])

            constraints.append(self.u[:, k] >= 0)
            constraints.append(self.u[:, k] <= 1)

            energy = c_u @ self.u[:, k]
            track = (
                self.params.lambda_T * cp.square(self.x[0, k] - self.xstar_p[k, 0])
                + self.params.lambda_H * cp.square(self.x[1, k] - self.xstar_p[k, 1])
                + self.params.lambda_C * cp.square(self.x[2, k] - self.xstar_p[k, 2])
                + self.params.lambda_L * cp.square(self.x[3, k] - self.xstar_p[k, 3])
            )
            slack = (
                self.params.slack_T * cp.square(self.v[0, k])
                + self.params.slack_H * cp.square(self.v[1, k])
                + self.params.slack_C * cp.square(self.v[2, k])
            )
            obj += (gamma**k) * (energy + track + slack)

        # terminal bounds (soft for T/H/C)
        constraints.append(self.x[0:3, K] >= self.xlo_p[K, 0:3] - self.v[:, K])
        constraints.append(self.x[0:3, K] <= self.xhi_p[K, 0:3] + self.v[:, K])
        constraints.append(self.x[3, K] >= self.xlo_p[K, 3])
        constraints.append(self.x[3, K] <= self.xhi_p[K, 3])

        terminal_slack = (
            self.params.slack_T * cp.square(self.v[0, K])
            + self.params.slack_H * cp.square(self.v[1, K])
            + self.params.slack_C * cp.square(self.v[2, K])
        )
        obj += (gamma**K) * terminal_slack

        self.prob = cp.Problem(cp.Minimize(obj), constraints)

    def _fill_time_params(self, t0) -> None:
        import pandas as pd

        K = self.params.K
        xlo = np.zeros((K + 1, 4), dtype=np.float64)
        xhi = np.zeros((K + 1, 4), dtype=np.float64)
        xstar = np.zeros((K, 4), dtype=np.float64)

        t0_ts = pd.Timestamp(t0)
        for k in range(K + 1):
            tk = (t0_ts + pd.Timedelta(seconds=self.params.dt_s * k)).to_pydatetime()
            lo, hi = x_bounds_for_time(tk, self.bounds)
            xlo[k, :] = lo
            xhi[k, :] = hi
            if k < K:
                xstar[k, :] = x_star_for_time(tk, self.bounds)

        self.xlo_p.value = xlo
        self.xhi_p.value = xhi
        self.xstar_p.value = xstar

    def solve(
        self,
        x0: ArrayF,
        d_pred: ArrayF,
        *,
        t0,
        warm_u_seq: Optional[ArrayF] = None,  # (K,8)
        tee: bool = False,
    ) -> Tuple[ArrayF, ArrayF, ArrayF, ArrayF, str, float]:
        """
        Returns:
          u0 (8,)
          u_seq (K,8)
          x_seq (K+1,4)
          v_seq (K+1,3)
          status
          objective
        """
        x0 = np.asarray(x0, dtype=np.float64).reshape(4,)
        d_pred = np.asarray(d_pred, dtype=np.float64)
        if d_pred.shape != (self.params.K, 4):
            raise ValueError(f"d_pred must be (K,4) where K={self.params.K}")

        self.x0_p.value = x0
        self.d_p.value = d_pred
        self._fill_time_params(t0=t0)

        if warm_u_seq is not None:
            warm_u_seq = clamp_u_seq(np.asarray(warm_u_seq, dtype=np.float64))
            if warm_u_seq.shape != (self.params.K, 8):
                raise ValueError(f"warm_u_seq must be (K,8), got {warm_u_seq.shape}")
            self.u.value = warm_u_seq.T

        if self.solver_name == "ecos":
            solve_kwargs = {"solver": cp.ECOS, "warm_start": True, "verbose": tee}
        else:
            solve_kwargs = {"solver": cp.OSQP, "warm_start": True, "verbose": tee}

        self.prob.solve(**solve_kwargs)

        status = str(self.prob.status)
        obj = float(self.prob.value) if self.prob.value is not None else float("nan")

        if status not in ("optimal", "optimal_inaccurate"):
            u0 = np.zeros((8,), dtype=np.float64)
            u_seq = np.zeros((self.params.K, 8), dtype=np.float64)
            x_seq = np.full((self.params.K + 1, 4), np.nan, dtype=np.float64)
            v_seq = np.full((self.params.K + 1, 3), np.nan, dtype=np.float64)
            return u0, u_seq, x_seq, v_seq, status, obj

        u_seq = np.asarray(self.u.value.T, dtype=np.float64)
        x_seq = np.asarray(self.x.value.T, dtype=np.float64)
        v_seq = np.asarray(self.v.value.T, dtype=np.float64)

        u0 = clamp01(u_seq[0, :])
        u_seq[0, :] = u0
        return u0, clamp_u_seq(u_seq), x_seq, v_seq, status, obj


def linear_one_step(model: LinearModel, x: ArrayF, u: ArrayF, d: ArrayF) -> ArrayF:
    x = np.asarray(x, dtype=np.float64).reshape(4,)
    u = np.asarray(u, dtype=np.float64).reshape(8,)
    d = np.asarray(d, dtype=np.float64).reshape(4,)
    return (model.M @ x) + (model.N @ u) + (model.O @ d) + model.m
