# =========================
# file: digital_twin_one_step_linear.py
# =========================
"""
One-step prediction using saved affine matrices:
    x_{k+1} = M x_k + N u_k + O d_k + m

Optionally compares with RK4 one-step to show approximation error.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from numpy.typing import NDArray

from GH_simulation_1st.digital_twin_for_real_response.digital_twin_one_step_RK4 import simulate_one_step

ArrayF = NDArray[np.float64]


# ============================================================
# EDIT THESE (easy typing spot)
# ============================================================
# State:                    x = [T_in,  H_in,  C_in,  L_DLI]
X_INI: ArrayF = np.array([19.00, 10.20, 1.08, 0.00], dtype=np.float64)

# Control:              u = [U_heat, U_fan, U_nat, U_pad, U_dos, U_LED, U_hum, U_dehum]
U: ArrayF = np.array([1.00, 0.00, 0.00, 0.00, 0.00, 1.00, 0.00, 0.00], dtype=np.float64)

# Disturbance:          d = [T_out, H_out, C_out, R_out]
D: ArrayF = np.array([19.00, 10.20, 1.08, 0.00], dtype=np.float64)
# ============================================================


@dataclass(frozen=True, slots=True)
class StepResult:
    t0: float
    t1: float
    x0: ArrayF
    x1: ArrayF


def load_linear_model(npz_path: Path) -> tuple[ArrayF, ArrayF, ArrayF, ArrayF]:
    data = np.load(npz_path)
    M = np.asarray(data["M"], dtype=np.float64)
    N = np.asarray(data["N"], dtype=np.float64)
    O = np.asarray(data["O"], dtype=np.float64)
    m = np.asarray(data["m"], dtype=np.float64)
    if M.shape != (4, 4):
        raise ValueError(f"M must be (4,4), got {M.shape}")
    if N.shape != (4, 8):
        raise ValueError(f"N must be (4,8), got {N.shape}")
    if O.shape != (4, 4):
        raise ValueError(f"O must be (4,4), got {O.shape}")
    if m.shape != (4,):
        raise ValueError(f"m must be (4,), got {m.shape}")
    return M, N, O, m


def simulate_one_step_linear(
    x_ini: ArrayF,
    u: ArrayF,
    d: ArrayF,
    M: ArrayF,
    N: ArrayF,
    O: ArrayF,
    m: ArrayF,
    t0: float = 0.0,
    horizon_s: float = 300.0,
) -> StepResult:
    x0 = np.asarray(x_ini, dtype=np.float64).copy()
    u = np.asarray(u, dtype=np.float64).copy()
    d = np.asarray(d, dtype=np.float64).copy()

    if x0.shape != (4,):
        raise ValueError(f"x_ini must be shape (4,), got {x0.shape}")
    if u.shape != (8,):
        raise ValueError(f"u must be shape (8,), got {u.shape}")
    if d.shape != (4,):
        raise ValueError(f"d must be shape (4,), got {d.shape}")

    x1 = (M @ x0) + (N @ u) + (O @ d) + m
    return StepResult(t0=float(t0), t1=float(t0 + horizon_s), x0=x0, x1=np.asarray(x1, dtype=np.float64))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default="linear_model_matrices.npz")
    ap.add_argument("--compare-rk4", action="store_true")
    ap.add_argument("--horizon-s", type=float, default=300.0)
    ap.add_argument("--dt-s", type=float, default=5.0)
    args = ap.parse_args()

    M, N, O, m = load_linear_model(Path(args.model))

    lin = simulate_one_step_linear(X_INI, U, D, M, N, O, m, horizon_s=args.horizon_s)
    print("Linear one-step")
    print("t0:", lin.t0)
    print("t1:", lin.t1)
    print("x0:", lin.x0)
    print("x1:", lin.x1)

    if args.compare_rk4:
        rk = simulate_one_step(
            x_ini=X_INI,
            u=U,
            d=D,
            horizon_s=args.horizon_s,
            dt_s=args.dt_s,
            t0=0.0,
        )
        err = lin.x1 - rk.x1
        print("\nRK4 one-step")
        print("x1:", rk.x1)
        print("\nError (linear - rk4):", err)
        print("RMSE:", float(np.sqrt(np.mean(err**2))))


if __name__ == "__main__":
    main()
